import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { getUsers, updateProfile, deleteUser } from '../services/crmService';
import { UserProfile } from '../types/crm';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription
} from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { 
  Users as UsersIcon,
  Shield,
  ShieldAlert,
  ShieldCheck,
  User,
  Search,
  MoreVertical,
  Mail,
  UserPlus,
  Edit2,
  Trash2,
  Phone,
  X,
  PlusCircle,
  AlertCircle
} from 'lucide-react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogDescription
} from '../components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select';
import { Label } from '../components/ui/label';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { 
  DropdownMenu, 
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem, 
  DropdownMenuSeparator, 
  DropdownMenuTrigger 
} from '../components/ui/dropdown-menu';
import { Input } from '../components/ui/input';
import { toast } from 'sonner';
import { motion } from 'framer-motion';

const UsersPage: React.FC = () => {
  const { profile, isAdmin } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    if (isAdmin) {
      getUsers().then(data => {
        if (data) setUsers(data);
        setIsLoading(false);
      });
    }
  }, [isAdmin]);

  const handleRoleChange = async (uid: string, newRole: 'admin' | 'manager' | 'sales') => {
    try {
      await updateProfile(uid, { role: newRole });
      setUsers(prev => prev.map(u => u.uid === uid ? { ...u, role: newRole } : u));
      toast.success(`User role updated to ${newRole}`);
    } catch (error) {
      toast.error('Failed to update role');
    }
  };

  const [editingUser, setEditingUser] = useState<UserProfile | null>(null);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<string | null>(null);

  const handleUpdateUser = async () => {
    if (!editingUser) return;
    try {
      await updateProfile(editingUser.uid, {
        name: editingUser.name,
        email: editingUser.email,
        mobile: editingUser.mobile,
        role: editingUser.role
      });
      setUsers(prev => prev.map(u => u.uid === editingUser.uid ? editingUser : u));
      setIsEditDialogOpen(false);
      toast.success('Operative profile updated');
    } catch (error) {
      toast.error('Update failed');
    }
  };

  const handleDeleteUser = async () => {
    if (!userToDelete) return;
    try {
      await deleteUser(userToDelete);
      setUsers(prev => prev.filter(u => u.uid !== userToDelete));
      setIsDeleteDialogOpen(false);
      toast.success('Operative archived');
    } catch (error) {
      toast.error('Deletion failed');
    }
  };

  const filteredUsers = (users || []).filter(u => 
    (u.name || '').toLowerCase().includes(searchTerm.toLowerCase()) || 
    (u.email || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
    (u.username || '').toLowerCase().includes(searchTerm.toLowerCase())
  );

  const RoleBadge = ({ role }: { role: string }) => {
    switch (role?.toLowerCase()) {
      case 'admin':
        return <Badge className="bg-[#FEF2F2] text-[#EF4444] border-[#FEE2E2] gap-1.5 font-bold uppercase text-[9px] tracking-wider px-2.5 py-1 rounded-full shadow-none hover:bg-[#FEE2E2] transition-colors"><ShieldAlert className="w-3 h-3" /> Admin</Badge>;
      case 'manager':
        return <Badge className="bg-[#EFF6FF] text-[#3B82F6] border-[#DBEAFE] gap-1.5 font-bold uppercase text-[9px] tracking-wider px-2.5 py-1 rounded-full shadow-none hover:bg-[#DBEAFE] transition-colors"><ShieldCheck className="w-3 h-3" /> Manager</Badge>;
      case 'sales':
        return <Badge className="bg-[#EEF2FF] text-[#4F46E5] border-[#E0E7FF] gap-1.5 font-bold uppercase text-[9px] tracking-wider px-2.5 py-1 rounded-full shadow-none hover:bg-[#E0E7FF] transition-colors"><User className="w-3 h-3" /> Sales</Badge>;
      default:
        return <Badge variant="outline" className="font-bold text-[9px] uppercase tracking-wider px-2.5 py-1 rounded-full border-[#E6EAF0]">{role}</Badge>;
    }
  };

  if (!isAdmin) {
    return (
      <div className="flex flex-col items-center justify-center p-20 glass-card bg-white border-[#E6EAF0]">
        <ShieldAlert className="w-12 h-12 text-[#EF4444] mb-4" />
        <h2 className="text-xl font-bold text-[#0F172A] tracking-tight">Access Denied</h2>
        <p className="text-[#64748B] font-medium mt-1">Requires Administrator Authorization.</p>
      </div>
    );
  }

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: [0.23, 1, 0.32, 1] }}
      className="space-y-8 pb-12"
    >
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-[10px] font-black text-[#4F46E5] uppercase tracking-[0.2em] mb-1">
            <ShieldCheck className="w-3.5 h-3.5" /> Security Protocol
          </div>
          <h2 className="text-3xl font-bold tracking-tight text-[#0F172A] dark:text-white">
            User <span className="text-[#64748B] font-medium">Dashboard</span>
          </h2>
          <p className="text-sm font-medium text-[#64748B] dark:text-slate-400">Manage identity governance and access level authorization.</p>
        </div>
        <Button className="h-12 px-8 rounded-xl bg-[#4F46E5] hover:bg-[#4338CA] text-white font-bold text-sm tracking-tight shadow-md transition-all active:scale-[0.98]">
           <UserPlus className="w-4 h-4 mr-2.5" />
           Add New User
        </Button>
      </div>

      <Card className="bg-white dark:bg-slate-950 border-[#E6EAF0] dark:border-white/5 shadow-sm rounded-2xl overflow-hidden">
        <div className="p-6 border-b border-[#E6EAF0] dark:border-white/5 bg-[#F8FAFC] dark:bg-white/[0.02] flex flex-col md:flex-row items-center gap-4">
          <div className="relative flex-1 w-full group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#94A3B8] group-focus-within:text-[#4F46E5] transition-colors" />
            <Input 
              placeholder="Search users by name or email..." 
              className="pl-11 h-12 rounded-xl border-[#E6EAF0] bg-white dark:bg-slate-900 font-medium text-sm focus:border-[#4F46E5]/40 focus:ring-4 focus:ring-[#4F46E5]/5 transition-all shadow-none"
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex items-center gap-3">
             <div className="h-12 px-5 rounded-xl border border-[#E6EAF0] dark:border-white/5 flex items-center bg-white dark:bg-slate-900 shadow-sm">
                <span className="text-[10px] font-bold text-[#94A3B8] uppercase tracking-widest mr-3 leading-none pt-0.5">Total Users:</span>
                <span className="text-base font-bold text-[#4F46E5] leading-none">{users.length}</span>
             </div>
          </div>
        </div>
        <CardContent className="p-6 bg-[#F6F8FB]/50">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {isLoading ? (
              Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="h-[180px] bg-white animate-pulse rounded-2xl border border-[#E6EAF0]" />
              ))
            ) : filteredUsers.map((u) => (
              <motion.div 
                layout
                key={u.uid} 
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-white dark:bg-slate-900 border border-[#E6EAF0] dark:border-white/5 rounded-2xl p-5 shadow-sm hover:shadow-md transition-all group flex flex-col justify-between"
              >
                <div className="flex justify-between items-start">
                   <div className="flex gap-4">
                      <Avatar className="w-12 h-12 rounded-xl border border-[#E6EAF0] shadow-sm">
                        <AvatarImage src={u.photoUrl} className="object-cover" />
                        <AvatarFallback className="bg-[#EEF2FF] text-[#4F46E5] font-bold">
                          {u.name?.charAt(0)}
                        </AvatarFallback>
                      </Avatar>
                      <div className="min-w-0">
                         <h4 className="text-base font-bold text-[#0F172A] dark:text-white truncate tracking-tight">{u.name}</h4>
                         <p className="text-[13px] text-[#64748B] dark:text-slate-400 font-medium truncate mt-0.5">{u.email}</p>
                      </div>
                   </div>
                   
                   <DropdownMenu>
                    <DropdownMenuTrigger
                      render={
                        <Button variant="ghost" size="icon" className="w-8 h-8 rounded-lg text-[#94A3B8] hover:bg-[#F8FAFC]" />
                      }
                    >
                      <MoreVertical className="w-4 h-4" />
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="w-56 p-1.5 rounded-xl border-[#E6EAF0] shadow-xl bg-white">
                      <DropdownMenuItem className="gap-2.5 font-bold text-xs py-2 rounded-lg" onClick={() => { setEditingUser(u); setIsEditDialogOpen(true); }}>
                        <Edit2 className="w-3.5 h-3.5" /> Edit Profile
                      </DropdownMenuItem>
                      <DropdownMenuSeparator className="bg-[#E6EAF0]" />
                      <DropdownMenuItem className="gap-2.5 font-bold text-xs py-2 rounded-lg text-rose-600 focus:bg-rose-50" onClick={() => { setUserToDelete(u.uid); setIsDeleteDialogOpen(true); }}>
                        <Trash2 className="w-3.5 h-3.5" /> Archive User
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>

                <div className="mt-6 flex items-center justify-between">
                   <RoleBadge role={u.role || 'sales'} />
                   <Button 
                    variant="ghost" 
                    size="icon" 
                    className="w-8 h-8 rounded-lg bg-[#F8FAFC] text-[#64748B] hover:bg-[#EEF2FF] hover:text-[#4F46E5] transition-colors"
                  >
                    <Mail className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </motion.div>
            ))}
          </div>
        </CardContent>
      </Card>
      {/* Edit User Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[480px] rounded-3xl p-0 overflow-hidden border-none shadow-2xl bg-[#F8FAFC] dark:bg-[#020617]">
          <DialogHeader className="p-6 bg-white dark:bg-slate-900 border-b border-[#E6EAF0] dark:border-white/5">
            <DialogTitle className="text-xl font-bold text-[#0F172A] dark:text-white tracking-tight flex items-center gap-3">
               <div className="w-10 h-10 rounded-xl bg-[#EEF2FF] flex items-center justify-center">
                 <Edit2 className="w-5 h-5 text-[#4F46E5]" />
               </div>
               Edit User Profile
            </DialogTitle>
            <DialogDescription className="text-xs font-medium text-[#64748B] mt-1">Adjust account settings and authorization levels.</DialogDescription>
          </DialogHeader>
          
          <div className="p-6 space-y-5">
            {editingUser && (
              <>
                <div className="space-y-1.5">
                  <Label className="text-[11px] font-bold text-[#64748B] uppercase tracking-wider ml-1">Full name</Label>
                  <Input 
                    value={editingUser.name || ''} 
                    onChange={e => setEditingUser({...editingUser, name: e.target.value})}
                    className="h-11 rounded-xl bg-white dark:bg-slate-900 border-[#E6EAF0] font-medium text-sm shadow-sm focus:border-[#4F46E5] focus:ring-4 focus:ring-[#4F46E5]/5 transition-all"
                    placeholder="Enter name..."
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label className="text-[11px] font-bold text-[#64748B] uppercase tracking-wider ml-1">Email address</Label>
                    <Input 
                      value={editingUser.email || ''} 
                      onChange={e => setEditingUser({...editingUser, email: e.target.value})}
                      className="h-11 rounded-xl bg-white dark:bg-slate-900 border-[#E6EAF0] font-medium text-sm shadow-sm focus:border-[#4F46E5] focus:ring-4 focus:ring-[#4F46E5]/5 transition-all"
                      placeholder="Email..."
                    />
                  </div>
                  <div className="space-y-1.5">
                    <Label className="text-[11px] font-bold text-[#64748B] uppercase tracking-wider ml-1">Mobile number</Label>
                    <Input 
                      value={editingUser.mobile || ''} 
                      onChange={e => setEditingUser({...editingUser, mobile: e.target.value})}
                      className="h-11 rounded-xl bg-white dark:bg-slate-900 border-[#E6EAF0] font-medium text-sm shadow-sm focus:border-[#4F46E5] focus:ring-4 focus:ring-[#4F46E5]/5 transition-all"
                      placeholder="Phone..."
                    />
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-[11px] font-bold text-[#64748B] uppercase tracking-wider ml-1">Account Role</Label>
                  <Select 
                    value={editingUser.role} 
                    onValueChange={(val: any) => setEditingUser({...editingUser, role: val})}
                  >
                    <SelectTrigger className="h-11 rounded-xl bg-white dark:bg-slate-900 border-[#E6EAF0] font-medium text-sm shadow-sm focus:border-[#4F46E5] focus:ring-4 focus:ring-[#4F46E5]/5 transition-all">
                      <SelectValue placeholder="Select Role" />
                    </SelectTrigger>
                    <SelectContent className="rounded-xl border-[#E6EAF0] shadow-xl">
                      <SelectItem value="admin" className="py-2.5 px-4 rounded-lg font-medium text-sm">Administrator</SelectItem>
                      <SelectItem value="manager" className="py-2.5 px-4 rounded-lg font-medium text-sm">Manager</SelectItem>
                      <SelectItem value="sales" className="py-2.5 px-4 rounded-lg font-medium text-sm">Sales Executive</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </>
            )}
          </div>

          <DialogFooter className="p-6 pt-0 flex gap-3">
             <Button variant="outline" onClick={() => setIsEditDialogOpen(false)} className="h-11 flex-1 rounded-xl font-bold text-xs uppercase tracking-wider border-[#E6EAF0]">Cancel</Button>
             <Button onClick={handleUpdateUser} className="h-11 flex-1 rounded-xl bg-[#4F46E5] hover:bg-[#4338CA] text-white font-bold text-xs uppercase tracking-wider shadow-md">Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="sm:max-w-[400px] rounded-3xl p-8 border-none shadow-2xl bg-white dark:bg-slate-950 text-center">
          <div className="w-16 h-16 rounded-2xl bg-[#FEF2F2] dark:bg-rose-950/30 flex items-center justify-center mx-auto mb-5">
            <Trash2 className="w-8 h-8 text-[#EF4444]" />
          </div>
          <h3 className="text-xl font-bold text-[#0F172A] dark:text-white tracking-tight">Deactivate User?</h3>
          <p className="text-[#64748B] text-sm font-medium mt-2 leading-relaxed">This will revoke all access for this user from the system. This action is sensitive.</p>
          
          <div className="flex flex-col gap-2 mt-8">
            <Button onClick={handleDeleteUser} className="h-12 w-full rounded-xl bg-[#EF4444] hover:bg-[#DC2626] text-white font-bold text-xs uppercase tracking-wider shadow-md">Confirm Deactivation</Button>
            <Button variant="ghost" onClick={() => setIsDeleteDialogOpen(false)} className="h-12 w-full rounded-xl font-bold text-xs uppercase tracking-wider text-[#64748B]">Back to Safety</Button>
          </div>
        </DialogContent>
      </Dialog>
    </motion.div>
  );
};

export default UsersPage;
