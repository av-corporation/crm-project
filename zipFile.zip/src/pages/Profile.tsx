import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { getUsers, deleteUser, createUser } from '../services/crmService';
import { UserProfile, UserRole } from '../types/crm';
import { db } from '../lib/firebase';
import { doc, updateDoc } from 'firebase/firestore';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription
} from '../components/ui/card';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '../components/ui/table';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '../components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '../components/ui/avatar';
import { Badge } from '../components/ui/badge';
import { Button } from '../components/ui/button';
import { 
  Shield, 
  User as UserIcon, 
  Mail, 
  ShieldCheck, 
  ShieldAlert,
  UserPlus,
  Globe,
  MapPin,
  Tag,
  Users,
  Trash2,
  Lock,
  Loader2,
  Share2,
  MessageCircle,
  Copy,
  CheckCircle2
} from 'lucide-react';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from '../components/ui/dialog';
import { Input } from '../components/ui/input';
import { toast } from 'sonner';
import { cn } from '../lib/utils';

import { motion, AnimatePresence } from 'framer-motion';

const Profile: React.FC = () => {
  const { profile, isAdmin } = useAuth();
  const [allUsers, setAllUsers] = useState<UserProfile[]>([]);
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [userToDelete, setUserToDelete] = useState<UserProfile | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [createdUserData, setCreatedUserData] = useState<UserProfile | null>(null);
  const [newUser, setNewUser] = useState({
    name: '',
    email: '',
    username: '',
    mobile: '',
    role: 'sales' as UserRole,
    password: ''
  });

  useEffect(() => {
    if (isAdmin) {
      getUsers().then(u => setAllUsers(u || []));
    }
  }, [isAdmin]);

  const handleRoleChange = async (uid: string, role: UserRole) => {
    try {
      await updateDoc(doc(db, 'users', uid), { role });
      setAllUsers(prev => prev.map(u => u.uid === uid ? { ...u, role } : u));
      toast.success(`Role updated to ${role}`);
    } catch (error) {
      toast.error('Failed to update role');
    }
  };

  const handleDeleteUser = async () => {
    if (!userToDelete) return;
    const uid = userToDelete.uid;

    if (uid === profile?.uid) {
      toast.error('You cannot delete your own account');
      setIsDeleteModalOpen(false);
      return;
    }

    if (userToDelete.role === 'admin' && userToDelete.isPrimary) {
      toast.error('Primary admin cannot be deleted');
      setIsDeleteModalOpen(false);
      return;
    }

    setIsDeleting(true);
    try {
      await deleteUser(uid);
      setAllUsers(prev => prev.filter(u => u.uid !== uid));
      toast.success('User deleted successfully');
      setIsDeleteModalOpen(false);
    } catch (error: any) {
      toast.error('Unable to delete user. Please try again.');
    } finally {
      setIsDeleting(false);
      setUserToDelete(null);
    }
  };

  const confirmDelete = (user: UserProfile) => {
    if (user.uid === profile?.uid) {
      toast.error('You cannot delete your own account');
      return;
    }
    if (user.role === 'admin' && user.isPrimary) {
      toast.error('Primary admin cannot be deleted');
      return;
    }
    setUserToDelete(user);
    setIsDeleteModalOpen(true);
  };

  const handleCreateUser = async () => {
    const trimmedName = newUser.name.trim();
    const trimmedUsername = newUser.username.trim().toLowerCase();
    const trimmedEmail = newUser.email.trim().toLowerCase();
    const trimmedMobile = newUser.mobile.trim();
    const trimmedPassword = (newUser.password || '123456').trim();

    if (!trimmedName || !trimmedUsername) {
      toast.error('Name and Username are required');
      return;
    }

    try {
      const uid = await createUser({
        name: trimmedName,
        email: trimmedEmail || undefined,
        username: trimmedUsername,
        mobile: trimmedMobile || undefined,
        role: newUser.role,
        password: trimmedPassword
      });

      if (uid) {
        const createdUser: UserProfile = {
          uid,
          name: trimmedName,
          email: trimmedEmail || undefined,
          username: trimmedUsername,
          mobile: trimmedMobile || undefined,
          role: newUser.role,
          password: trimmedPassword,
          mustChangePassword: true,
          createdAt: new Date().toISOString()
        };
        setAllUsers(prev => [...prev, createdUser]);
        setCreatedUserData(createdUser);
        setIsAddUserOpen(false);
        setIsShareModalOpen(true);
        setNewUser({ name: '', email: '', username: '', mobile: '', role: 'sales', password: '' });
        toast.success('User added successfully');
      }
    } catch (error: any) {
      toast.error(error.message || 'Failed to create user');
    }
  };

  const generateShareMessage = (user: UserProfile) => {
    const loginUrl = `${window.location.origin}/login?username=${user.username}`;
    return `Hello ${user.name},

Your CRM account has been created.

Login Details:
Username: ${user.username}
Password: ${user.password || '123456'}

Login here:
${loginUrl}

Regards,
A V Corporation`;
  };

  const handleCopyLink = (user: UserProfile) => {
    const message = generateShareMessage(user);
    navigator.clipboard.writeText(message);
    toast.success('Copied successfully');
  };

  const handleWhatsAppShare = (user: UserProfile) => {
    if (!user.mobile) return;
    const message = generateShareMessage(user);
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/${user.mobile}?text=${encodedMessage}`, '_blank');
  };

  const handleEmailShare = (user: UserProfile) => {
    const subject = encodeURIComponent('Your CRM Login Details');
    const body = encodeURIComponent(generateShareMessage(user));
    window.open(`mailto:${user.email || ''}?subject=${subject}&body=${body}`, '_blank');
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto animate-in fade-in duration-500">
      {/* Share Login Details Modal */}
      <Dialog open={isShareModalOpen} onOpenChange={setIsShareModalOpen}>
        <DialogContent className="sm:max-w-[450px] rounded-3xl dark:bg-slate-900 border-none shadow-2xl p-0 overflow-hidden">
          <div className="p-8 text-center bg-gradient-to-b from-emerald-50 to-white dark:from-emerald-900/20 dark:to-transparent">
            <div className="w-20 h-20 bg-emerald-100 dark:bg-emerald-900/30 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle2 className="w-10 h-10 text-emerald-600 dark:text-emerald-400" />
            </div>
            <DialogTitle className="text-2xl font-bold dark:text-white tracking-tight mb-2">User Created Successfully</DialogTitle>
            <DialogDescription className="text-slate-500 dark:text-slate-400 font-medium text-sm">
              Share the login credentials with the user.
            </DialogDescription>
          </div>

          <div className="p-8 space-y-6">
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Username</p>
                <p className="font-bold text-slate-900 dark:text-white">{createdUserData?.username}</p>
              </div>
              <div className="p-4 bg-slate-50 dark:bg-slate-800 rounded-2xl border border-slate-100 dark:border-slate-700">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Password</p>
                <p className="font-bold text-slate-900 dark:text-white">{createdUserData?.password || '123456'}</p>
              </div>
            </div>

            <div className="space-y-3">
              <Button 
                onClick={() => createdUserData && handleWhatsAppShare(createdUserData)}
                disabled={!createdUserData?.mobile}
                className="w-full h-12 bg-[#25D366] hover:bg-[#20ba59] text-white font-bold text-sm gap-3 rounded-xl shadow-lg shadow-emerald-500/10 disabled:opacity-50"
              >
                <MessageCircle className="w-5 h-5" />
                Send via WhatsApp
              </Button>
              
              <Button 
                onClick={() => createdUserData && handleCopyLink(createdUserData)}
                className="btn-primary w-full h-12 text-sm gap-3"
              >
                <Copy className="w-5 h-5" />
                Copy Details & Link
              </Button>

              <Button 
                onClick={() => createdUserData && handleEmailShare(createdUserData)}
                className="btn-secondary w-full h-12 text-sm gap-3"
              >
                <Mail className="w-5 h-5" />
                Send via Email
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Modal */}
      <Dialog open={isDeleteModalOpen} onOpenChange={setIsDeleteModalOpen}>
        <DialogContent className="sm:max-w-[400px] rounded-3xl dark:bg-slate-900 border-none shadow-2xl p-0 overflow-hidden">
          <div className="p-8 text-center bg-red-50/50 dark:bg-red-900/10">
            <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShieldAlert className="w-8 h-8 text-red-600 dark:text-red-400" />
            </div>
            <DialogTitle className="text-xl font-bold dark:text-white tracking-tight mb-2">Confirm Deletion</DialogTitle>
            <DialogDescription className="text-slate-500 dark:text-slate-400 font-medium text-sm">
              Are you sure you want to delete <span className="text-red-600 dark:text-red-400 font-bold">{userToDelete?.name}</span>? This action cannot be undone.
            </DialogDescription>
          </div>
          <DialogFooter className="p-6 pt-0 flex flex-row gap-3 sm:justify-center">
            <Button 
              className="btn-secondary flex-1 h-11"
              onClick={() => setIsDeleteModalOpen(false)}
            >
              Cancel
            </Button>
            <Button 
              className="btn-danger flex-1 h-11"
              onClick={handleDeleteUser}
              disabled={isDeleting}
            >
              {isDeleting ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Delete User'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="saas-card overflow-hidden border-none shadow-premium relative bg-white dark:bg-slate-950"
      >
        <div className="h-48 bg-gradient-to-r from-indigo-600 via-indigo-500 to-indigo-400 relative">
          <div className="absolute inset-0 bg-white/5 opacity-20 pointer-events-none" style={{ backgroundImage: 'radial-gradient(circle at 1px 1px, white 1px, transparent 0)', backgroundSize: '24px 24px' }}></div>
          <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
          
          <div className="absolute -bottom-16 left-10 flex items-end gap-8">
            <div className="relative">
              <div className="absolute inset-0 bg-indigo-500/20 blur-2xl rounded-full scale-110"></div>
              <Avatar className="w-40 h-40 border-[6px] border-white dark:border-slate-950 shadow-2xl relative z-10 p-1 bg-white dark:bg-white/10">
                <AvatarImage src={profile?.photoUrl} className="rounded-full" />
                <AvatarFallback className="text-4xl font-black bg-indigo-50 dark:bg-indigo-900/40 text-indigo-600 dark:text-indigo-400">
                  {profile?.name?.charAt(0)}
                </AvatarFallback>
              </Avatar>
            </div>
            
            <div className="pb-6 space-y-2">
              <div className="flex items-center gap-3">
                <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">{profile?.name}</h2>
                <Badge className={cn(
                  "px-4 py-1.5 rounded-lg font-black text-[9px] uppercase tracking-[0.2em] border-none shadow-premium",
                  profile?.role === 'admin' ? "bg-rose-500 text-white" :
                  profile?.role === 'manager' ? "bg-amber-500 text-white" :
                  "bg-indigo-600 text-white"
                )}>
                  {profile?.role} Clearance
                </Badge>
              </div>
              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2.5 text-[11px] font-bold text-slate-400 uppercase tracking-widest">
                  <Mail className="w-3.5 h-3.5 text-indigo-500" />
                  {profile?.email}
                </div>
                {profile?.mobile && (
                  <div className="flex items-center gap-2.5 text-[11px] font-bold text-slate-400 uppercase tracking-widest pl-6 border-l border-slate-100 dark:border-white/10">
                    <MessageCircle className="w-3.5 h-3.5 text-emerald-500" />
                    {profile?.mobile}
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
        <div className="h-24"></div>
      </motion.div>

      {/* Admin User Management */}
      {isAdmin && (
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="saas-card overflow-hidden border-none shadow-premium bg-white dark:bg-slate-950"
        >
          <div className="flex flex-col md:flex-row md:items-center justify-between p-10 gap-6">
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-[10px] font-black text-indigo-500 uppercase tracking-[0.2em]">
                <Users className="w-3.5 h-3.5 fill-current" /> Identity Engine
              </div>
              <h3 className="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Team Architecture</h3>
              <p className="text-xs font-bold text-slate-400 opacity-70">Manage operative access level, roles, and communication tunnels.</p>
            </div>
            <Dialog open={isAddUserOpen} onOpenChange={setIsAddUserOpen}>
              <DialogTrigger
                render={
                  <Button className="h-14 px-10 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-black uppercase text-[10px] tracking-[0.2em] shadow-xl shadow-indigo-600/20 active:scale-[0.98] transition-all" />
                }
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Deploy Operative
              </DialogTrigger>
              <DialogContent className="rounded-[32px] border-none shadow-3xl p-0 overflow-hidden max-w-lg bg-white dark:bg-slate-900">
                <div className="bg-indigo-600 p-8 text-white">
                   <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center mb-4">
                     <UserPlus className="w-6 h-6" />
                   </div>
                   <DialogTitle className="text-2xl font-black tracking-tight">Create CRM Profile</DialogTitle>
                   <p className="text-xs font-bold text-indigo-100 uppercase tracking-widest mt-1">Configure new operative credentials</p>
                </div>
                <div className="p-8 space-y-6">
                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Full Name</label>
                       <Input 
                        placeholder="John Doe" 
                        className="h-12 rounded-xl border-none bg-slate-50 dark:bg-slate-950 font-bold px-4 shadow-inner" 
                        value={newUser.name}
                        onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                      />
                    </div>
                    <div className="space-y-2">
                       <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Username</label>
                       <Input 
                        placeholder="johndoe" 
                        className="h-12 rounded-xl border-none bg-slate-50 dark:bg-slate-950 font-bold px-4 shadow-inner" 
                        value={newUser.username}
                        onChange={(e) => setNewUser({ ...newUser, username: e.target.value })}
                      />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Mobile Context (for WhatsApp)</label>
                    <Input 
                      placeholder="9876543210 (Prefix with country code)" 
                      className="h-12 rounded-xl border-none bg-slate-50 dark:bg-slate-950 font-bold px-4 shadow-inner" 
                      value={newUser.mobile}
                      onChange={(e) => setNewUser({ ...newUser, mobile: e.target.value })}
                    />
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Access Tier</label>
                      <Select 
                        value={newUser.role} 
                        onValueChange={(val: UserRole) => setNewUser({ ...newUser, role: val })}
                      >
                        <SelectTrigger className="h-12 rounded-xl border-none bg-slate-50 dark:bg-slate-950 font-bold px-4 shadow-inner">
                          <SelectValue placeholder="Role Selection" />
                        </SelectTrigger>
                        <SelectContent className="rounded-xl shadow-2xl border-none p-2">
                          <SelectItem value="admin" className="rounded-lg font-bold">Administrator</SelectItem>
                          <SelectItem value="manager" className="rounded-lg font-bold">Team Manager</SelectItem>
                          <SelectItem value="sales" className="rounded-lg font-bold">Sales Lead</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Password</label>
                      <Input 
                        type="text" 
                        placeholder="Default: 123456" 
                        className="h-12 rounded-xl border-none bg-slate-50 dark:bg-slate-950 font-bold px-4 shadow-inner" 
                        value={newUser.password}
                        onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                      />
                    </div>
                  </div>
                </div>
                <div className="px-8 pb-8 flex gap-4">
                  <Button variant="ghost" onClick={() => setIsAddUserOpen(false)} className="rounded-2xl h-12 flex-1 font-bold">Cancel</Button>
                  <Button className="h-12 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-black uppercase text-[10px] tracking-widest flex-[2] shadow-xl shadow-indigo-600/20" onClick={handleCreateUser}>
                    Engage Operative
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
          <div className="px-5 pb-5">
            <div className="overflow-x-auto rounded-[24px] border border-slate-100 dark:border-white/5">
              <Table>
                <TableHeader className="bg-slate-50 dark:bg-white/5">
                  <TableRow className="border-slate-100 dark:border-white/5">
                    <TableHead className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-8 py-6">Identified Operative</TableHead>
                    <TableHead className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-8 py-6">Status & Activity</TableHead>
                    <TableHead className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-8 py-6">Clearance Level</TableHead>
                    <TableHead className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] px-8 py-6 text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody className="bg-white dark:bg-slate-950 divide-y divide-slate-100 dark:divide-white/5">
                  {allUsers.map((u) => (
                    <TableRow key={u.uid} className="group hover:bg-slate-50 dark:hover:bg-indigo-500/[0.03] transition-all h-24">
                      <TableCell className="px-8">
                        <div className="flex items-center gap-5">
                          <Avatar className="w-12 h-12 border-2 border-white dark:border-slate-800 shadow-premium transition-transform group-hover:scale-105">
                            <AvatarImage src={u.photoUrl} />
                            <AvatarFallback className="bg-gradient-to-br from-indigo-50 to-indigo-100 dark:from-indigo-900/40 dark:to-indigo-900/60 text-indigo-600 dark:text-indigo-400 font-black text-sm">
                              {u.name.slice(0, 1)}
                            </AvatarFallback>
                          </Avatar>
                          <div className="flex flex-col space-y-0.5">
                            <span className="font-black text-slate-900 dark:text-white tracking-tight">{u.name}</span>
                            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{u.username} • {u.email || 'NO_ENDPOINT'}</span>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell className="px-8">
                        <div className="flex flex-col gap-1">
                          <div className="flex items-center gap-2">
                             <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]" />
                             <span className="text-[10px] font-black text-slate-600 dark:text-slate-400 uppercase tracking-widest">Active System</span>
                          </div>
                          <span className="text-[9px] font-bold text-slate-400 uppercase tracking-tighter">Last Access: 43m ago</span>
                        </div>
                      </TableCell>
                      <TableCell className="px-8">
                         <div className="flex flex-col gap-2">
                            <Badge className={cn(
                              "w-fit rounded-lg px-3 py-1 font-black text-[9px] uppercase tracking-[0.2em] border-none shadow-sm",
                              u.role === 'admin' ? "bg-rose-500 text-white" :
                              u.role === 'manager' ? "bg-amber-500 text-white" : "bg-indigo-600 text-white"
                            )}>
                              {u.role}
                            </Badge>
                         </div>
                      </TableCell>
                      <TableCell className="px-8 text-right">
                        <div className="flex items-center justify-end gap-3 opacity-0 group-hover:opacity-100 transition-all duration-300 translate-x-4 group-hover:translate-x-0">
                          <Select 
                            value={u.role} 
                            onValueChange={(role: UserRole) => handleRoleChange(u.uid, role)}
                            disabled={u.uid === profile?.uid}
                          >
                            <SelectTrigger className="w-[140px] h-10 text-[9px] font-black uppercase tracking-widest rounded-xl bg-slate-50 dark:bg-slate-900 border-none shadow-inner px-4">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent className="rounded-2xl border-none shadow-3xl p-2 min-w-[160px] bg-white dark:bg-slate-800">
                              <SelectItem value="admin" className="rounded-xl py-3 font-bold text-[10px] uppercase tracking-widest">Administrator</SelectItem>
                              <SelectItem value="manager" className="rounded-xl py-3 font-bold text-[10px] uppercase tracking-widest">Team Manager</SelectItem>
                              <SelectItem value="sales" className="rounded-xl py-3 font-bold text-[10px] uppercase tracking-widest">Sales Lead</SelectItem>
                              <SelectItem value="user" className="rounded-xl py-3 font-bold text-[10px] uppercase tracking-widest">Limited User</SelectItem>
                            </SelectContent>
                          </Select>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-10 w-10 text-rose-500 hover:text-white hover:bg-rose-500 rounded-xl transition-all shadow-sm active:scale-90"
                            disabled={u.uid === profile?.uid || (u.role === 'admin' && u.isPrimary)}
                            onClick={() => confirmDelete(u)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default Profile;
