import React, { useState } from 'react';
import { 
  Zap, 
  Plus, 
  MessageSquare, 
  Save, 
  Trash2, 
  Play, 
  Clock, 
  Filter,
  MoreVertical,
  CheckCircle2,
  AlertCircle,
  Smartphone,
  Send,
  Code
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { toast } from 'sonner';

import { Card } from '../components/ui/card';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Badge } from '../components/ui/badge';
import { 
  Tabs, 
  TabsContent, 
  TabsList, 
  TabsTrigger 
} from '../components/ui/tabs';
import { 
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
  DialogDescription
} from '../components/ui/dialog';
import { Textarea } from '../components/ui/textarea';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import { Switch } from '../components/ui/switch';

// Dummy Data
const initialTemplates = [
  { id: '1', name: 'Welcome Message', content: 'Hi {{name}}, Welcome to A V CORPORATION! We received your inquiry about {{product}}.', category: 'Marketing' },
  { id: '2', name: 'Follow-up (24h)', content: 'Hello {{name}}, just following up on our conversation from yesterday.', category: 'Sales' },
  { id: '3', name: 'Meeting Scheduled', content: 'Hi {{name}}, your meeting is confirmed for {{date}} at {{time}}.', category: 'Service' },
];

const initialRules = [
  { id: '1', name: 'New Lead Auto-Reply', trigger: 'Lead Created', action: 'Send Welcome Message', status: 'active' },
  { id: '2', name: 'Abandoned Cart Follow-up', trigger: 'Status Changed to Cold', action: 'Send Follow-up (24h)', status: 'inactive' },
];

const Automation: React.FC = () => {
  const [templates, setTemplates] = useState(initialTemplates);
  const [rules, setRules] = useState(initialRules);
  const [activeTab, setActiveTab] = useState('templates');
  const [isAddingTemplate, setIsAddingTemplate] = useState(false);
  const [isAddingRule, setIsAddingRule] = useState(false);

  const [newTemplate, setNewTemplate] = useState({ name: '', content: '', category: 'Marketing' });
  const [newRule, setNewRule] = useState({ name: '', trigger: 'Lead Created', action: 'Send Welcome Message', status: 'active' });

  const handleAddTemplate = () => {
    if (!newTemplate.name || !newTemplate.content) {
      toast.error('Please fill all template fields');
      return;
    }
    setTemplates([...templates, { ...newTemplate, id: Date.now().toString() }]);
    setNewTemplate({ name: '', content: '', category: 'Marketing' });
    setIsAddingTemplate(false);
    toast.success('Template saved successfully');
  };

  const handleAddRule = () => {
    if (!newRule.name) {
      toast.error('Please name your rule');
      return;
    }
    setRules([...rules, { ...newRule, id: Date.now().toString(), status: 'active' as const }]);
    setNewRule({ name: '', trigger: 'Lead Created', action: 'Send Welcome Message', status: 'active' });
    setIsAddingRule(false);
    toast.success('Automation rule activated');
  };

  const deleteTemplate = (id: string) => {
    setTemplates(templates.filter(t => t.id !== id));
    toast.info('Template deleted');
  };

  const deleteRule = (id: string) => {
    setRules(rules.filter(r => r.id !== id));
    toast.info('Rule removed');
  };

  return (
    <div className="space-y-8 pb-12 animate-in fade-in duration-700">
      {/* Premium Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2 text-[10px] font-black text-indigo-500 uppercase tracking-[0.2em] mb-1">
            <Zap className="w-3.5 h-3.5 fill-current" /> CRM Engine
          </div>
          <h1 className="text-4xl font-black text-slate-900 dark:text-white tracking-tight">
            Automation <span className="text-slate-400 font-light">&</span> Workflows
          </h1>
          <p className="text-xs font-bold text-slate-500 dark:text-slate-400 opacity-70">Define triggers and templates for cross-channel engagement.</p>
        </div>
        <div className="flex items-center gap-3">
           <div className="px-5 py-3 rounded-2xl bg-white dark:bg-slate-900 border border-slate-100 dark:border-white/5 shadow-sm flex items-center gap-3">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span className="text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300">WhatsApp Node Active</span>
           </div>
           <Button 
             onClick={() => activeTab === 'templates' ? setIsAddingTemplate(true) : setIsAddingRule(true)}
             className="h-12 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-black uppercase text-[10px] tracking-[0.15em] px-8 shadow-xl shadow-indigo-500/20 active:scale-[0.98] transition-all"
           >
             <Plus className="w-4 h-4 mr-2" />
             {activeTab === 'templates' ? 'New Message' : 'New Trigger'}
           </Button>
        </div>
      </div>

      <Tabs defaultValue="templates" className="w-full" onValueChange={setActiveTab}>
        <div className="flex items-center gap-4 mb-10 overflow-x-auto pb-2 scrollbar-hide">
          <TabsList className="bg-slate-100/50 dark:bg-white/5 p-1 rounded-[20px] h-14 border-none shadow-inner w-fit">
            <TabsTrigger value="templates" className="rounded-xl px-10 h-full font-black text-[10px] uppercase tracking-widest data-[state=active]:bg-white dark:data-[state=active]:bg-slate-900 data-[state=active]:text-indigo-600 data-[state=active]:shadow-xl transition-all">
              Templates
            </TabsTrigger>
            <TabsTrigger value="rules" className="rounded-xl px-10 h-full font-black text-[10px] uppercase tracking-widest data-[state=active]:bg-white dark:data-[state=active]:bg-slate-900 data-[state=active]:text-indigo-600 data-[state=active]:shadow-xl transition-all">
              Flow Rules
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="templates" className="mt-0">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <AnimatePresence mode="popLayout">
              {templates.map((tpl) => (
                <motion.div
                  key={tpl.id}
                  layout
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.9 }}
                >
                  <Card className="saas-card group overflow-hidden border-none shadow-premium hover:shadow-indigo-500/10 transition-all duration-500">
                    <div className="p-8 space-y-6">
                      <div className="flex justify-between items-start">
                        <div className="w-12 h-12 rounded-2xl bg-indigo-50 dark:bg-indigo-900/30 flex items-center justify-center text-indigo-600 transition-transform group-hover:scale-110 duration-500">
                          <MessageSquare className="w-6 h-6 fill-current opacity-30" />
                        </div>
                        <Badge variant="outline" className={cn(
                          "rounded-lg border-none px-3 py-1 font-black text-[9px] uppercase tracking-widest",
                          tpl.category === 'Marketing' ? 'bg-indigo-50 text-indigo-600' :
                          tpl.category === 'Sales' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-600'
                        )}>
                          {tpl.category}
                        </Badge>
                      </div>
                      
                      <div className="space-y-1">
                        <h3 className="text-xl font-black text-slate-900 dark:text-white tracking-tight">{tpl.name}</h3>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Last updated 2 days ago</p>
                      </div>

                      <div className="relative">
                        <div className="p-5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-white/5 min-h-[100px]">
                          <p className="text-sm font-medium text-slate-600 dark:text-slate-400 italic leading-relaxed">
                            "{tpl.content.replace(/\{\{/g, '⟨').replace(/\}\}/g, '⟩')}"
                          </p>
                        </div>
                        <div className="absolute top-3 right-3 text-[9px] font-black text-indigo-200 uppercase tracking-widest pointer-events-none">Payload</div>
                      </div>

                      <div className="flex items-center justify-between pt-4 border-t border-slate-100 dark:border-white/5">
                        <Button size="sm" variant="ghost" className="rounded-xl h-10 px-4 text-rose-500 font-bold hover:bg-rose-50 border border-transparent hover:border-rose-100 transition-all" onClick={() => deleteTemplate(tpl.id)}>
                          <Trash2 className="w-4 h-4 mr-2" /> Delete
                        </Button>
                        <Button size="sm" className="h-10 px-6 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-white/10 text-slate-600 dark:text-slate-300 font-black text-[10px] uppercase tracking-widest shadow-sm hover:shadow-md transition-all">
                          Edit Logic
                        </Button>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </TabsContent>

        <TabsContent value="rules" className="mt-0">
          <div className="grid grid-cols-1 gap-6">
            <AnimatePresence mode="popLayout">
              {rules.map((rule) => (
                <motion.div
                  key={rule.id}
                  layout
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                >
                  <Card className="p-2 rounded-[24px] border-none saas-card group hover:shadow-indigo-500/10 transition-all duration-300">
                    <div className="flex flex-col md:flex-row items-center gap-6 p-6">
                      <div className="flex items-center gap-5 flex-1 w-full md:w-auto">
                        <div className={cn(
                          "w-16 h-16 rounded-2xl flex items-center justify-center shadow-premium transition-all duration-500 group-hover:scale-105",
                          rule.status === 'active' ? "bg-indigo-600 text-white" : "bg-slate-100 dark:bg-white/5 text-slate-400 border border-slate-200 dark:border-white/10 shadow-none"
                        )}>
                          <Zap className={cn("w-7 h-7", rule.status === 'active' ? "fill-current" : "")} />
                        </div>
                        <div className="flex-1 min-w-0 space-y-1">
                          <div className="flex items-center gap-3">
                            <h3 className="font-black text-slate-900 dark:text-white text-xl uppercase tracking-tight">{rule.name}</h3>
                            {rule.status === 'active' && <Badge className="bg-emerald-500/10 text-emerald-500 border-none text-[8px] font-black uppercase tracking-widest px-2">Live</Badge>}
                          </div>
                          <div className="flex flex-wrap items-center gap-x-6 gap-y-1">
                            <div className="flex items-center gap-2">
                               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">When</span>
                               <Badge variant="outline" className="rounded-md border-indigo-100 dark:border-indigo-500/20 text-indigo-600 text-[10px] font-bold px-2 py-0.5">{rule.trigger}</Badge>
                            </div>
                            <div className="flex items-center gap-2">
                               <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Perform</span>
                               <Badge variant="outline" className="rounded-md border-amber-100 dark:border-amber-500/20 text-amber-600 text-[10px] font-bold px-2 py-0.5">{rule.action}</Badge>
                            </div>
                          </div>
                        </div>
                      </div>
  
                      <div className="flex items-center gap-6 w-full md:w-auto justify-between md:justify-end border-t md:border-t-0 pt-4 md:pt-0 border-slate-100 dark:border-white/5">
                        <div className="flex items-center gap-4 py-2.5 px-5 rounded-2xl bg-slate-50 dark:bg-slate-950 border border-slate-100 dark:border-white/5">
                           <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active</span>
                           <Switch 
                             checked={rule.status === 'active'} 
                             className="data-[state=checked]:bg-indigo-600 shadow-sm"
                             onCheckedChange={() => {
                               setRules(rules.map(r => r.id === rule.id ? { ...r, status: r.status === 'active' ? 'inactive' : 'active' } : r));
                             }} 
                           />
                        </div>
                        <div className="flex items-center gap-2">
                          <Button size="icon" variant="ghost" className="w-11 h-11 rounded-xl hover:bg-rose-50 hover:text-rose-500 transition-colors" onClick={() => deleteRule(rule.id)}>
                            <Trash2 className="w-5 h-5" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </Card>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        </TabsContent>
      </Tabs>

      {/* Template Dialog */}
      <Dialog open={isAddingTemplate} onOpenChange={setIsAddingTemplate}>
        <DialogContent className="rounded-[32px] border-none shadow-3xl p-0 overflow-hidden max-w-2xl bg-white dark:bg-slate-950">
          <div className="bg-indigo-600 p-10 text-white relative overflow-hidden">
             <div className="absolute top-0 right-0 w-40 h-40 bg-white/10 rounded-full translate-x-1/2 -translate-y-1/2 blur-3xl" />
             <MessageSquare className="w-12 h-12 mb-4 text-indigo-200" />
             <DialogTitle className="text-3xl font-black tracking-tight">Design Response Payload</DialogTitle>
             <p className="text-indigo-100 font-bold text-sm mt-2 opacity-80 uppercase tracking-wider">Craft a high-converting automated message</p>
          </div>
          <div className="p-10 space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Template Alias</label>
                <Input 
                  placeholder="e.g. Welcome Message" 
                  value={newTemplate.name}
                  onChange={(e) => setNewTemplate({...newTemplate, name: e.target.value})}
                  className="h-14 rounded-2xl border-none bg-slate-50 dark:bg-slate-900 font-bold text-base shadow-inner px-6"
                />
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Flow Category</label>
                <Select value={newTemplate.category} onValueChange={(v) => setNewTemplate({...newTemplate, category: v})}>
                  <SelectTrigger className="h-14 rounded-2xl border-none bg-slate-50 dark:bg-slate-900 font-bold text-sm shadow-inner px-6">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-2xl border-none shadow-2xl">
                    <SelectItem value="Marketing" className="font-bold">Marketing Automation</SelectItem>
                    <SelectItem value="Sales" className="font-bold">Sales Outreach</SelectItem>
                    <SelectItem value="Service" className="font-bold">Customer Support</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between items-center ml-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Message Content</label>
                <div className="flex gap-2">
                  <Badge variant="outline" className="text-[9px] font-bold text-indigo-500 border-indigo-200">⟨name⟩</Badge>
                  <Badge variant="outline" className="text-[9px] font-bold text-indigo-500 border-indigo-200">⟨product⟩</Badge>
                </div>
              </div>
              <Textarea 
                placeholder="Hi ⟨name⟩, Welcome to..." 
                value={newTemplate.content}
                onChange={(e) => setNewTemplate({...newTemplate, content: e.target.value})}
                className="min-h-[160px] rounded-[24px] border-none bg-slate-50 dark:bg-slate-900 font-medium text-base shadow-inner p-6 resize-none focus:ring-2 focus:ring-indigo-500/20 transition-all"
              />
              <p className="text-[10px] font-bold text-slate-400 italic mt-2 ml-1">Use ⟨tags⟩ to inject dynamic lead data from the CRM.</p>
            </div>
          </div>
          <div className="px-10 pb-10 flex gap-4">
             <Button variant="ghost" onClick={() => setIsAddingTemplate(false)} className="rounded-2xl font-black text-[10px] uppercase tracking-widest h-14 flex-1">Discard Draft</Button>
             <Button onClick={handleAddTemplate} className="h-14 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-black uppercase text-xs tracking-widest flex-1 shadow-xl shadow-indigo-600/20 active:scale-[0.98]">
               Deploy Template
             </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Rule Dialog */}
      <Dialog open={isAddingRule} onOpenChange={setIsAddingRule}>
        <DialogContent className="rounded-[40px] border-none shadow-2xl p-0 overflow-hidden">
          <div className="bg-amber-500 p-10 text-white">
             <Zap className="w-12 h-12 mb-4 opacity-50 fill-white" />
             <DialogTitle className="text-3xl font-black">Create Automation Rule</DialogTitle>
             <DialogDescription className="text-amber-50 font-medium mt-2">Trigger events based on lead behavior.</DialogDescription>
          </div>
          <div className="p-10 space-y-6">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Rule Name</label>
              <Input 
                placeholder="e.g. Follow-up after 1 hour" 
                value={newRule.name}
                onChange={(e) => setNewRule({...newRule, name: e.target.value})}
                className="h-14 rounded-2xl border-none bg-slate-50 dark:bg-slate-950 font-bold text-sm shadow-inner px-5"
              />
            </div>
            <div className="grid grid-cols-2 gap-6">
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Trigger Event</label>
                <Select value={newRule.trigger} onValueChange={(v) => setNewRule({...newRule, trigger: v})}>
                  <SelectTrigger className="h-14 rounded-2xl border-none bg-slate-50 dark:bg-slate-950 font-bold text-sm shadow-inner px-5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-2xl">
                    <SelectItem value="Lead Created" className="font-bold">Lead Created</SelectItem>
                    <SelectItem value="Status Changed" className="font-bold">Status Changed</SelectItem>
                    <SelectItem value="Note Added" className="font-bold">Note Added</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Exec Action</label>
                <Select value={newRule.action} onValueChange={(v) => setNewRule({...newRule, action: v})}>
                  <SelectTrigger className="h-14 rounded-2xl border-none bg-slate-50 dark:bg-slate-950 font-bold text-sm shadow-inner px-5">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="rounded-2xl">
                    {templates.map(tpl => (
                      <SelectItem key={tpl.id} value={`Send ${tpl.name}`} className="font-bold">Send {tpl.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
          <div className="px-10 pb-10 flex gap-4">
             <Button variant="ghost" onClick={() => setIsAddingRule(false)} className="rounded-2xl font-bold h-14 flex-1">Cancel</Button>
             <Button onClick={handleAddRule} className="h-14 rounded-2xl bg-amber-500 hover:bg-amber-600 text-white font-black uppercase text-xs tracking-widest flex-1 shadow-xl shadow-amber-500/20">
               <Zap className="w-4 h-4 mr-2" />
               Activate Rule
             </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Automation;

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
